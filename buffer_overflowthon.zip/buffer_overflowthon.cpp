#include <iostream>
using namespace std;
int main(void)
{
  int arr[10];			//here the size of array at the time of initiliazation is 10
  int arr_num;			//i.e. the arr is provided with 10 integer spaces to store integer values
  int num,i;			//if we enter a char it can be seen that 
  						//cin(function to take input in c++) goes into a failed state and that 
  						// makes it ignore further calls to it, till the error flag and buffer are reset.
  						//which essential makes it go in an infinite loop 
   cout << "Enter the count of numbers? ";	//here we are requested to enter number of vaules we want to enter
   cin >> num;								//for example if we enter a value greater than that of arr size(which is 10)
   											//----for example we enter value of num=99 which is greater than array size----
											//it can be seen that the program crashes and goes to an infinite loop
  for (i = 0; i < num; i++)					//which ultimately becomes a case of buffer overflow as the input values to 
  {											//memory exceeds the expected number of input values 
    cout << "Enter a number to be stored: ";
    cin >> arr_num;
    arr[i]= arr_num;
  }
  for(int i=0;i<10;i++){
  	cout<<i<<"th element of array is : "<<arr[i]<<endl;		//To illustrate the overflow I have taken a pointer 
  }															//which currently points to the last element of the array 
  int *ptr=&arr[9];										//as the indexing of the array starts with 0 so we are taking arr[9]
  while(ptr!=NULL){										//as the final element and then i started the pointer from arr[9] to onwards 
  	cout<<"elements beyond array size are -- "<<*ptr<<"--which are at mem location : "<<ptr<<endl; //shows the value stored at different
  	ptr++;																						//memory locations beyond array
  }
  return 0;
}
